package com.Frazia.Wattpad;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WattpadApplicationTests {

	@Test
	void contextLoads() {
	}

}
