package com.Frazia.Wattpad;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WattpadApplication {

	public static void main(String[] args) {
		SpringApplication.run(WattpadApplication.class, args);
	}

}
